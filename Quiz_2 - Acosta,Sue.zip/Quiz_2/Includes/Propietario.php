<?php
class Propietario {
    private $conn;
    private $table_name = "propietarios";

    // Propiedades
    public $id;
    public $tipo_propietario;
    public $nombre;
    public $numero_identificacion;
    public $domicilio;
    public $telefono;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function registrar() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (tipo_propietario, nombre, numero_identificacion, domicilio, telefono) 
                  VALUES 
                  (:tipo_propietario, :nombre, :numero_identificacion, :domicilio, :telefono)";

        $stmt = $this->conn->prepare($query);

        // Limpiar los datos
        $this->sanitizarDatos();

        // Vincular los valores
        $stmt->bindParam(":tipo_propietario", $this->tipo_propietario);
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":numero_identificacion", $this->numero_identificacion);
        $stmt->bindParam(":domicilio", $this->domicilio);
        $stmt->bindParam(":telefono", $this->telefono);

        // Ejecutar la query
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function obtener($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if($row) {
            $this->id = $row['id'];
            $this->tipo_propietario = $row['tipo_propietario'];
            $this->nombre = $row['nombre'];
            $this->numero_identificacion = $row['numero_identificacion'];
            $this->domicilio = $row['domicilio'];
            $this->telefono = $row['telefono'];
            return true;
        }
        return false;
    }

    public function actualizar() {
        $query = "UPDATE " . $this->table_name . " 
                  SET tipo_propietario = :tipo_propietario, 
                      nombre = :nombre, 
                      numero_identificacion = :numero_identificacion, 
                      domicilio = :domicilio, 
                      telefono = :telefono 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Limpiar los datos
        $this->sanitizarDatos();

        // Vincular los valores
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":tipo_propietario", $this->tipo_propietario);
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":numero_identificacion", $this->numero_identificacion);
        $stmt->bindParam(":domicilio", $this->domicilio);
        $stmt->bindParam(":telefono", $this->telefono);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function eliminar($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    private function sanitizarDatos() {
        $this->tipo_propietario = htmlspecialchars(strip_tags($this->tipo_propietario));
        $this->nombre = htmlspecialchars(strip_tags($this->nombre));
        $this->numero_identificacion = htmlspecialchars(strip_tags($this->numero_identificacion));
        $this->domicilio = htmlspecialchars(strip_tags($this->domicilio));
        $this->telefono = htmlspecialchars(strip_tags($this->telefono));
    }
}
?>