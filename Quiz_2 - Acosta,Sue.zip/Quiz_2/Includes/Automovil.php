<?php
class Automovil {
    private $conn;
    private $table_name = "vehiculos";

    // Propiedades
    public $id;
    public $propietario_id;
    public $vin;
    public $placa;
    public $marca;
    public $modelo;
    public $anio_fabricacion;
    public $color;
    public $tipo_vehiculo;
    public $capacidad_motor;
    public $numero_cilindros;
    public $tipo_combustible;
    public $peso_bruto;
    public $transmision;

    // Constructor que recibe la conexión a la base de datos
    public function __construct($db) {
        $this->conn = $db;
    }

    // Método para registrar un nuevo automóvil
    public function registrar() {
        $query = "INSERT INTO " . $this->table_name . "
                (propietario_id, vin, placa, marca, modelo, anio_fabricacion, 
                color, tipo_vehiculo, capacidad_motor, numero_cilindros, 
                tipo_combustible, peso_bruto, transmision)
                VALUES
                (:propietario_id, :vin, :placa, :marca, :modelo, :anio_fabricacion,
                :color, :tipo_vehiculo, :capacidad_motor, :numero_cilindros,
                :tipo_combustible, :peso_bruto, :transmision)";

        $stmt = $this->conn->prepare($query);

        // Limpiar y sanitizar datos
        $this->sanitizarDatos();

        // Vincular valores
        $stmt->bindParam(":propietario_id", $this->propietario_id);
        $stmt->bindParam(":vin", $this->vin);
        $stmt->bindParam(":placa", $this->placa);
        $stmt->bindParam(":marca", $this->marca);
        $stmt->bindParam(":modelo", $this->modelo);
        $stmt->bindParam(":anio_fabricacion", $this->anio_fabricacion);
        $stmt->bindParam(":color", $this->color);
        $stmt->bindParam(":tipo_vehiculo", $this->tipo_vehiculo);
        $stmt->bindParam(":capacidad_motor", $this->capacidad_motor);
        $stmt->bindParam(":numero_cilindros", $this->numero_cilindros);
        $stmt->bindParam(":tipo_combustible", $this->tipo_combustible);
        $stmt->bindParam(":peso_bruto", $this->peso_bruto);
        $stmt->bindParam(":transmision", $this->transmision);

        return $stmt->execute();
    }

    public function obtenerAutomoviles() {
        // Query para obtener todos los automóviles
        $query = "SELECT * FROM " . $this->table_name;

        // Preparar la declaración
        $stmt = $this->conn->prepare($query);

        // Ejecutar la consulta
        $stmt->execute();

        return $stmt;
    }

    public function buscarAutomoviles($searchTerm) {
        if ($searchTerm) {
            // Si hay un término de búsqueda, filtrar por placa o modelo
            $query = "SELECT * FROM " . $this->table_name . " WHERE Placa LIKE :searchTerm OR id LIKE :searchTerm";
            $stmt = $this->conn->prepare($query);
            $searchTerm = "%{$searchTerm}%"; // Añadir comodines para la búsqueda con LIKE
            $stmt->bindParam(':searchTerm', $searchTerm);
        } else {
            // Si no hay término de búsqueda, obtener todos los registros
            $query = "SELECT * FROM " . $this->table_name;
            $stmt = $this->conn->prepare($query);
        }
    
        // Ejecutar la consulta
        $stmt->execute();
    
        return $stmt;
    }

    public function obtenerAutomovilPorId($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }


    public function actualizarAutomovil($id) {
        $query = "UPDATE " . $this->table_name . "
                   SET placa = :placa, marca = :marca, modelo = :modelo, anio_fabricacion = :anio, color = :color
                   WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        // Limpiar los datos
        $this->placa = htmlspecialchars(strip_tags($this->placa));
        $this->marca = htmlspecialchars(strip_tags($this->marca));
        $this->modelo = htmlspecialchars(strip_tags($this->modelo));
        $this->anio = htmlspecialchars(strip_tags($this->anio));
        $this->color = htmlspecialchars(strip_tags($this->color));
        
        // Enlazar los parámetros
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':placa', $this->placa);
        $stmt->bindParam(':marca', $this->marca);
        $stmt->bindParam(':modelo', $this->modelo);
        $stmt->bindParam(':anio', $this->anio);
        $stmt->bindParam(':color', $this->color);
        
        // Ejecutar la consulta
        if ($stmt->execute()) {
            return true;
        } else {
            // Si falla, puedes imprimir el error para depurar
            print_r($stmt->errorInfo());
            return false;
        }
    }

    private function sanitizarDatos() {
        $this->vin = htmlspecialchars(strip_tags($this->vin));
        $this->placa = htmlspecialchars(strip_tags($this->placa));
        $this->marca = htmlspecialchars(strip_tags($this->marca));
        $this->modelo = htmlspecialchars(strip_tags($this->modelo));
        $this->color = htmlspecialchars(strip_tags($this->color));
        $this->tipo_vehiculo = htmlspecialchars(strip_tags($this->tipo_vehiculo));
        $this->tipo_combustible = htmlspecialchars(strip_tags($this->tipo_combustible));
        $this->transmision = htmlspecialchars(strip_tags($this->transmision));
    }


    public function obtenerCompleto($id) {
        $query = "SELECT a.*, 
                         p.tipo_propietario, p.nombre as nombre_propietario, 
                         p.numero_identificacion, p.domicilio, p.telefono,
                         s.aseguradora, s.numero_poliza, s.fecha_inicio, 
                         s.fecha_vencimiento
                  FROM " . $this->table_name . " a
                  LEFT JOIN propietarios p ON a.propietario_id = p.id
                  LEFT JOIN seguros s ON s.vehiculo_id = a.id
                  WHERE a.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
 }
?>