<?php
class Seguro {
    private $conn;
    private $table_name = "seguros";

    // Propiedades
    public $id;
    public $vehiculo_id;
    public $aseguradora;
    public $numero_poliza;
    public $fecha_inicio;
    public $fecha_vencimiento;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function registrar() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (vehiculo_id, aseguradora, numero_poliza, fecha_inicio, fecha_vencimiento) 
                  VALUES 
                  (:vehiculo_id, :aseguradora, :numero_poliza, :fecha_inicio, :fecha_vencimiento)";

        $stmt = $this->conn->prepare($query);

        // Limpiar los datos
        $this->sanitizarDatos();

        // Vincular los valores
        $stmt->bindParam(":vehiculo_id", $this->vehiculo_id);
        $stmt->bindParam(":aseguradora", $this->aseguradora);
        $stmt->bindParam(":numero_poliza", $this->numero_poliza);
        $stmt->bindParam(":fecha_inicio", $this->fecha_inicio);
        $stmt->bindParam(":fecha_vencimiento", $this->fecha_vencimiento);

        // Ejecutar la query
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function obtener($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if($row) {
            $this->id = $row['id'];
            $this->vehiculo_id = $row['vehiculo_id'];
            $this->aseguradora = $row['aseguradora'];
            $this->numero_poliza = $row['numero_poliza'];
            $this->fecha_inicio = $row['fecha_inicio'];
            $this->fecha_vencimiento = $row['fecha_vencimiento'];
            return true;
        }
        return false;
    }

    public function actualizar() {
        $query = "UPDATE " . $this->table_name . " 
                  SET vehiculo_id = :vehiculo_id, 
                      aseguradora = :aseguradora, 
                      numero_poliza = :numero_poliza, 
                      fecha_inicio = :fecha_inicio, 
                      fecha_vencimiento = :fecha_vencimiento 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Limpiar los datos
        $this->sanitizarDatos();

        // Vincular los valores
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":vehiculo_id", $this->vehiculo_id);
        $stmt->bindParam(":aseguradora", $this->aseguradora);
        $stmt->bindParam(":numero_poliza", $this->numero_poliza);
        $stmt->bindParam(":fecha_inicio", $this->fecha_inicio);
        $stmt->bindParam(":fecha_vencimiento", $this->fecha_vencimiento);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function eliminar($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    private function sanitizarDatos() {
        $this->aseguradora = htmlspecialchars(strip_tags($this->aseguradora));
        $this->numero_poliza = htmlspecialchars(strip_tags($this->numero_poliza));
        $this->fecha_inicio = htmlspecialchars(strip_tags($this->fecha_inicio));
        $this->fecha_vencimiento = htmlspecialchars(strip_tags($this->fecha_vencimiento));
    }
}
?>