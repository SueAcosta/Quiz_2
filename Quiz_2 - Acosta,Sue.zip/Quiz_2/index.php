<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión de Automóviles</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <div class="wrapper">
        <header>
            <h1>Sistema de Gestión de Automóviles</h1>
        </header>

        <main>
            <nav class="menu">
                <a href="Vistas/registrar_automovil.php" class="menu-item">
                    <div class="menu-text">
                        <h2>Registrar Automóvil</h2>
                        <p>Agregar nuevo vehículo</p>
                    </div>
                </a>
                
                <a href="Vistas/buscar_automovil.php" class="menu-item">
                    <div class="menu-text">
                        <h2>Buscar Automóvil</h2>
                        <p>Consultar registros</p>
                    </div>
                </a>
            </nav>
        </main>

        <footer>
            <p>Sue Acosta | 8-1002-1727 | 1LS131</p>
        </footer>
    </div>
</body>
</html>