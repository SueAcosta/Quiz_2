<?php
$projectPath = 'C:/Users/usuario/Documents/universidad utp/utp/desarrollo de software/DLS-7/4. Actividades o Asignaciones/6. Otros/Practica#2';
set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);

// Ahora podemos incluir los archivos usando rutas relativas a $projectPath
require_once 'includes/Database.php';
require_once 'includes/Automovil.php';
require_once 'includes/Propietario.php';
require_once 'includes/Seguro.php';

// Crear instancia de la base de datos
$database = new Database();
$db = $database->getConnection();

try {
    // Iniciar transacción
    $db->beginTransaction();

    // 1. Registrar propietario
    $propietario = new Propietario($db);
    $propietario->tipo_propietario = $_POST['tipo_propietario'];
    $propietario->nombre = $_POST['nombre_propietario'];
    $propietario->numero_identificacion = $_POST['numero_identificacion'];
    $propietario->domicilio = $_POST['domicilio'];
    $propietario->telefono = $_POST['telefono'];
    
    if (!$propietario->registrar()) {
        throw new Exception("Error al registrar el propietario");
    }
    
    $propietario_id = $db->lastInsertId();

    // 2. Registrar vehículo
    $vehiculo = new Automovil($db);
    $vehiculo->propietario_id = $propietario_id;
    $vehiculo->vin = $_POST['vin'];
    $vehiculo->placa = $_POST['placa'];
    $vehiculo->marca = $_POST['marca'];
    $vehiculo->modelo = $_POST['modelo'];
    $vehiculo->anio_fabricacion = $_POST['anio_fabricacion'];
    $vehiculo->color = $_POST['color'];
    $vehiculo->tipo_vehiculo = $_POST['tipo_vehiculo'];
    $vehiculo->capacidad_motor = $_POST['capacidad_motor'];
    $vehiculo->numero_cilindros = $_POST['numero_cilindros'];
    $vehiculo->tipo_combustible = $_POST['tipo_combustible'];
    $vehiculo->peso_bruto = $_POST['peso_bruto'];
    $vehiculo->transmision = $_POST['transmision'];

    if (!$vehiculo->registrar()) {
        throw new Exception("Error al registrar el vehículo");
    }

    $vehiculo_id = $db->lastInsertId();

    // 3. Registrar seguro
    $seguro = new Seguro($db);
    $seguro->vehiculo_id = $vehiculo_id;
    $seguro->aseguradora = $_POST['aseguradora'];
    $seguro->numero_poliza = $_POST['numero_poliza'];
    $seguro->fecha_inicio = $_POST['fecha_inicio'];
    $seguro->fecha_vencimiento = $_POST['fecha_vencimiento'];

    if (!$seguro->registrar()) {
        throw new Exception("Error al registrar el seguro");
    }

    // Confirmar transacción
    $db->commit();
    
    header("Location: /index.php?mensaje=registrado");
    exit();

} catch (Exception $e) {
    // Revertir cambios si hay error
    $db->rollBack();
    header("Location: /index.php?mensaje=error&error=" . urlencode($e->getMessage()));
    exit();
}
?>