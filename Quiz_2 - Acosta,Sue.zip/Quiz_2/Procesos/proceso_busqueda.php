<?php

$projectPath = 'C:/Users/usuario/Documents/universidad utp/utp/desarrollo de software/DLS-7/4. Actividades o Asignaciones/6. Otros/Practica#2';
set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);

require_once 'includes/Database.php';
require_once 'includes/Automovil.php';

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    die("Error de conexión a la base de datos.");
}

$automovil = new Automovil($db);
$resultados = $automovil->obtenerTodos();

echo "Número de automóviles encontrados: " . count($resultados) . "<br>";
?>
