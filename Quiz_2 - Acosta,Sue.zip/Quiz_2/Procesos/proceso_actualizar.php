<?php
// Incluir la conexión a la base de datos y la clase Automovil
$projectPath = 'C:/Users/usuario/Documents/universidad utp/utp/desarrollo de software/DLS-7/4. Actividades o Asignaciones/6. Otros/Practica#2';
set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);

require_once 'includes/Database.php';
require_once 'includes/Automovil.php';

// Crear una instancia de la clase Database y obtener la conexión
$database = new Database();
$db = $database->getConnection();

// Crear una instancia de la clase Automovil
$automovil = new Automovil($db);

$id = $automovil->id = htmlspecialchars(strip_tags($_POST['id']));
$automovil->placa = htmlspecialchars(strip_tags($_POST['placa']));
$automovil->marca = htmlspecialchars(strip_tags($_POST['marca']));
$automovil->modelo = htmlspecialchars(strip_tags($_POST['modelo']));
$automovil->anio = htmlspecialchars(strip_tags($_POST['anio']));
$automovil->color = htmlspecialchars(strip_tags($_POST['color']));


// Actualizar los datos del automóvil
if ($automovil->actualizarAutomovil($id)) {
    echo "se actualizo corre";
    header("Location: /Vistas/buscar_automovil.php?mensaje=actualizado");
    exit();
} else {
    header("Location: /buscar_automovil.php?mensaje=actualizado");
    exit();
}
?>