<?php
$projectPath = 'C:/Users/usuario/Documents/universidad utp/utp/desarrollo de software/DLS-7/4. Actividades o Asignaciones/6. Otros/Practica#2';
set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);

require_once 'includes/Database.php';
require_once 'includes/Automovil.php';

$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id) {
    header("Location: /busqueda.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$automovil = new Automovil($db);
$datos = $automovil->obtenerCompleto($id);

if (!$datos) {
    die("No se encontró el vehículo especificado");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Vehículo</title>
    <link rel="stylesheet" href="../css/detalle.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Detalle del Vehículo</h1>
        </header>

        <main>
            <!-- Datos del Vehículo -->
            <section class="card">
                <h2>Datos del Vehículo</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Placa</label>
                        <span><?php echo htmlspecialchars($datos['placa']) ?></span>
                    </div>
                    <div class="info-item">
                        <label>Marca</label>
                        <span><?php echo htmlspecialchars($datos['marca']) ?></span>
                    </div>
                    <div class="info-item">
                        <label>Modelo</label>
                        <span><?php echo htmlspecialchars($datos['modelo']) ?></span>
                    </div>
                    <div class="info-item">
                        <label>Año</label>
                        <span><?php echo htmlspecialchars($datos['anio_fabricacion']) ?></span>
                    </div>
                    <div class="info-item">
                        <label>Color</label>
                        <span><?php echo htmlspecialchars($datos['color']) ?></span>
                    </div>
                </div>
            </section>

            <!-- Datos del Propietario -->
            <section class="card">
                <h2>Datos del Propietario</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Nombre</label>
                        <span><?php echo htmlspecialchars($datos['nombre_propietario'] ?? 'No disponible') ?></span>
                    </div>
                    <div class="info-item">
                        <label>Identificación</label>
                        <span><?php echo htmlspecialchars($datos['numero_identificacion'] ?? 'No disponible') ?></span>
                    </div>
                    <div class="info-item">
                        <label>Teléfono</label>
                        <span><?php echo htmlspecialchars($datos['telefono'] ?? 'No disponible') ?></span>
                    </div>
                    <div class="info-item">
                        <label>Domicilio</label>
                        <span><?php echo htmlspecialchars($datos['domicilio'] ?? 'No disponible') ?></span>
                    </div>
                </div>
            </section>

            <!-- Datos del Seguro -->
            <section class="card">
                <h2>Datos del Seguro</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Aseguradora</label>
                        <span><?php echo htmlspecialchars($datos['aseguradora'] ?? 'No disponible') ?></span>
                    </div>
                    <div class="info-item">
                        <label>Número de Póliza</label>
                        <span><?php echo htmlspecialchars($datos['numero_poliza'] ?? 'No disponible') ?></span>
                    </div>
                    <div class="info-item">
                        <label>Fecha de Inicio</label>
                        <span><?php echo isset($datos['fecha_inicio']) ? date('d/m/Y', strtotime($datos['fecha_inicio'])) : 'No disponible' ?></span>
                    </div>
                    <div class="info-item">
                        <label>Fecha de Vencimiento</label>
                        <span><?php echo isset($datos['fecha_vencimiento']) ? date('d/m/Y', strtotime($datos['fecha_vencimiento'])) : 'No disponible' ?></span>
                    </div>
                </div>
            </section>

            <div class="actions">
                <a href="generar_pdf.php?id=<?php echo $id ?>" class="btn btn-primary">Descargar PDF</a>
                <a href="../index.php" class="btn btn-secondary">Regresar</a>
            </div>
        </main>
    </div>
</body>
</html>