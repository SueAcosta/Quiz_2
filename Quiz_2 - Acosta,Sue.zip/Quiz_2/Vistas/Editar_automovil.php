<?php
$projectPath = 'C:/Users/usuario/Documents/universidad utp/utp/desarrollo de software/DLS-7/4. Actividades o Asignaciones/6. Otros/Practica#2';
set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);

require_once 'includes/Database.php';
require_once 'includes/Automovil.php';

$database = new Database();
$db = $database->getConnection();
$automovil = new Automovil($db);
$id = isset($_GET['id']) ? htmlspecialchars(strip_tags($_GET['id'])) : '';
$fila = $automovil->obtenerAutomovilPorId($id);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Automóvil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../css/editar.css">
</head>
<body>
    <div class="container">
        <h1>Editar Automóvil</h1>

        <?php if($fila) { ?>
            <form action="/Procesos/proceso_actualizar.php" method="post">
                <div class="form-group">
                    <label for="id">ID</label>
                    <div class="input-group">
                        <i class="fas fa-hashtag"></i>
                        <input type="text" id="id" name="id" value="<?php echo htmlspecialchars($fila['id']); ?>" readonly>
                    </div>
                </div>

                <div class="form-group">
                    <label for="placa">Placa</label>
                    <div class="input-group">
                        <i class="fas fa-car"></i>
                        <input type="text" id="placa" name="placa" value="<?php echo htmlspecialchars($fila['placa']); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="marca">Marca</label>
                    <div class="input-group">
                        <i class="fas fa-trademark"></i>
                        <input type="text" id="marca" name="marca" value="<?php echo htmlspecialchars($fila['marca']); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="modelo">Modelo</label>
                    <div class="input-group">
                        <i class="fas fa-car-side"></i>
                        <input type="text" id="modelo" name="modelo" value="<?php echo htmlspecialchars($fila['modelo']); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="anio">Año</label>
                    <div class="input-group">
                        <i class="fas fa-calendar"></i>
                        <input type="number" id="anio" name="anio" value="<?php echo htmlspecialchars($fila['anio_fabricacion']); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="color">Color</label>
                    <div class="input-group">
                        <i class="fas fa-palette"></i>
                        <input type="text" id="color" name="color" value="<?php echo htmlspecialchars($fila['color']); ?>" required>
                    </div>
                </div>

                <div class="actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                    <a href="/Vistas/buscar_automovil.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Cancelar
                    </a>
                </div>
            </form>
        <?php } else { ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i>
                <p>No se encontró el automóvil</p>
            </div>
        <?php } ?>
    </div>
</body>
</html>