<?php
$projectPath = 'C:/Users/usuario/Documents/universidad utp/utp/desarrollo de software/DLS-7/4. Actividades o Asignaciones/6. Otros/Practica#2';
set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);

require_once 'includes/Database.php';
require_once 'includes/Automovil.php';
require_once 'fdpf/fpdf.php';

class PDF extends FPDF {
    // Colores en escala de grises
    private $darkGrey = [68, 68, 68];    // #444444
    private $mediumGrey = [119, 119, 119]; // #777777
    private $lightGrey = [238, 238, 238];  // #EEEEEE

    function Header() {
        // Encabezado con fondo gris oscuro
        $this->SetFillColor($this->darkGrey[0], $this->darkGrey[1], $this->darkGrey[2]);
        $this->Rect(0, 0, 220, 35, 'F');
        
        // Título
        $this->SetFont('Arial', 'B', 20);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(0, 25, 'Datos del Vehiculo', 0, 1, 'C');
        
        $this->Ln(15);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor($this->mediumGrey[0], $this->mediumGrey[1], $this->mediumGrey[2]);
        $this->Cell(0, 10, 'Pagina ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    function SectionTitle($title) {
        $this->SetDrawColor($this->darkGrey[0], $this->darkGrey[1], $this->darkGrey[2]);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        
        $this->Ln(5);
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor($this->darkGrey[0], $this->darkGrey[1], $this->darkGrey[2]);
        $this->Cell(0, 10, $title, 0, 1, 'L');
        $this->Ln(2);
    }

    function AddInfoSection($title, $data) {
        $this->SectionTitle($title);
        
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor($this->darkGrey[0], $this->darkGrey[1], $this->darkGrey[2]);
        
        $this->SetFillColor($this->lightGrey[0], $this->lightGrey[1], $this->lightGrey[2]);
        $fill = true;
        
        foreach($data as $label => $value) {
            $this->SetFont('Arial', 'B', 10);
            $this->Cell(50, 8, $label . ':', 0, 0, 'L', $fill);
            $this->SetFont('Arial', '', 10);
            $this->Cell(0, 8, utf8_decode($value), 0, 1, 'L', $fill);
            $fill = !$fill;
        }
        $this->Ln(5);
    }

    function AddSummary($content) {
        $this->SetFillColor($this->lightGrey[0], $this->lightGrey[1], $this->lightGrey[2]);
        $this->Rect($this->GetX(), $this->GetY(), 170, 25, 'F');
        
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor($this->darkGrey[0], $this->darkGrey[1], $this->darkGrey[2]);
        $this->SetX($this->GetX() + 5);
        $this->MultiCell(160, 8, utf8_decode($content), 0, 'L');
        
        $this->Ln(10);
    }
}

try {
    // Obtener datos
    $id = isset($_GET['id']) ? $_GET['id'] : die('ID no proporcionado');
    $database = new Database();
    $db = $database->getConnection();
    $automovil = new Automovil($db);
    $datos = $automovil->obtenerCompleto($id);

    if (!$datos) {
        die('No se encontraron datos del vehículo');
    }

    // Crear PDF
    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetMargins(20, 20, 20);

    // Resumen del vehículo
    $pdf->AddSummary(
        "Registro detallado del vehículo {$datos['marca']} {$datos['modelo']}, " .
        "identificado con la placa {$datos['placa']}."
    );

    // Datos del Vehículo
    $vehiculoData = [
        'Placa' => $datos['placa'],
        'Marca' => $datos['marca'],
        'Modelo' => $datos['modelo'],
        'Año' => $datos['anio_fabricacion'],
        'Color' => $datos['color']
    ];
    $pdf->AddInfoSection('Información del Vehículo', $vehiculoData);

    // Datos del Propietario
    if (isset($datos['nombre_propietario'])) {
        $propietarioData = [
            'Nombre' => $datos['nombre_propietario'],
            'Identificación' => $datos['numero_identificacion'],
            'Teléfono' => $datos['telefono'],
            'Domicilio' => $datos['domicilio']
        ];
        $pdf->AddInfoSection('Datos del Propietario', $propietarioData);
    }

    // Datos del Seguro
    if (isset($datos['aseguradora'])) {
        $seguroData = [
            'Aseguradora' => $datos['aseguradora'],
            'Número de Póliza' => $datos['numero_poliza'],
            'Inicio' => date('d/m/Y', strtotime($datos['fecha_inicio'])),
            'Vencimiento' => date('d/m/Y', strtotime($datos['fecha_vencimiento']))
        ];
        $pdf->AddInfoSection('Información del Seguro', $seguroData);
    }

    // Generar PDF
    $pdf->Output('D', 'vehiculo_'.$id.'.pdf');
    
} catch (Exception $e) {
    error_log("Error al generar PDF: " . $e->getMessage());
    die("Error al generar el PDF. Por favor, intente nuevamente.");
}
?>