<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda de Automóviles</title>
    <script src="https://kit.fontawesome.com/03a883a222.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/buscar.css">
</head>
<body>
    <div class="container">
        <h2>Búsqueda de Automóvil</h2>
        <div class="search-section">
            <form action="" method="GET" class="search-box">
                <input type="text" 
                       name="search" 
                       placeholder="Buscar por placa o modelo..." 
                       value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            </form>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i>
                Buscar
            </button>
            <a href="/index.php" class="btn btn-secondary">
                <i class="fas fa-home"></i>
                Volver al Inicio
            </a>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Placa</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Año</th>
                        <th>Color</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $projectPath = 'C:\Users\suema\Downloads\Quiz_2';
                    set_include_path(get_include_path() . PATH_SEPARATOR . $projectPath);
                    
                    require_once 'includes/Database.php';
                    require_once 'includes/Automovil.php';
        
                    $database = new Database();
                    $db = $database->getConnection();
                    $automovil = new Automovil($db);
                    $searchTerm = isset($_GET['search']) ? htmlspecialchars(strip_tags($_GET['search'])) : '';
                    $resultado = $automovil->buscarAutomoviles($searchTerm);

                    if ($resultado->rowCount() > 0) {
                        while ($fila = $resultado->fetch(PDO::FETCH_ASSOC)) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($fila['id']) . '</td>';
                            echo '<td>' . htmlspecialchars($fila['placa']) . '</td>';
                            echo '<td>' . htmlspecialchars($fila['marca']) . '</td>';
                            echo '<td>' . htmlspecialchars($fila['modelo']) . '</td>';
                            echo '<td>' . htmlspecialchars($fila['anio_fabricacion']) . '</td>';
                            echo '<td>' . htmlspecialchars($fila['color']) . '</td>';
                            echo '<td class="action-buttons">
                                    <a href="/Vistas/Detalles_vehiulos.php?id='. htmlspecialchars($fila['id']) . '" class="btn-action btn-view" title="Ver detalles">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    <a href="/Vistas/Editar_automovil.php?id='. htmlspecialchars($fila['id']) . '" class="btn-action btn-edit" title="Editar">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <a href="javascript:void(0)" onclick="confirmarEliminar('. htmlspecialchars($fila['id']) .')" class="btn-action btn-delete" title="Eliminar">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="7" class="empty-message">No se encontraron automóviles registrados.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function confirmarEliminar(id) {
            if (confirm('¿Está seguro de que desea eliminar este vehículo?')) {
                window.location.href = '/Procesos/procesos_eliminar.php?id=' + id;
            }
        }
    </script>
</body>
</html>