<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Vehículos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../css/registrar.css">
</head>
<body>
    <div class="container">
        <h1>Registro de Vehículo</h1>

        <form action="/Procesos/procesar_registro.php" method="post">
            <!-- Datos del Vehículo -->
            <section class="form-section">
                <h2><i class="fas fa-car"></i> Datos del Vehículo</h2>
                <div class="form-grid">
                    <div class="input-group">
                        <label for="vin">VIN</label>
                        <input type="text" id="vin" name="vin" maxlength="17" required>
                    </div>
                    <div class="input-group">
                        <label for="placa">Placa</label>
                        <input type="text" id="placa" name="placa" required>
                    </div>
                    <div class="input-group">
                        <label for="marca">Marca</label>
                        <input type="text" id="marca" name="marca" required>
                    </div>
                    <div class="input-group">
                        <label for="modelo">Modelo</label>
                        <input type="text" id="modelo" name="modelo" required>
                    </div>
                    <div class="input-group">
                        <label for="anio_fabricacion">Año de Fabricación</label>
                        <input type="number" id="anio_fabricacion" name="anio_fabricacion" required>
                    </div>
                    <div class="input-group">
                        <label for="color">Color</label>
                        <input type="text" id="color" name="color" required>
                    </div>
                    <div class="input-group">
                        <label for="tipo_vehiculo">Tipo de Vehículo</label>
                        <select id="tipo_vehiculo" name="tipo_vehiculo" required>
                            <option value="">Seleccione tipo</option>
                            <option value="sedan">Sedán</option>
                            <option value="suv">SUV</option>
                            <option value="camioneta">Camioneta</option>
                            <option value="motocicleta">Motocicleta</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label for="capacidad_motor">Capacidad del Motor (cc)</label>
                        <input type="number" id="capacidad_motor" name="capacidad_motor" required>
                    </div>
                    <div class="input-group">
                        <label for="tipo_combustible">Tipo de Combustible</label>
                        <select id="tipo_combustible" name="tipo_combustible" required>
                            <option value="">Seleccione combustible</option>
                            <option value="gasolina">Gasolina</option>
                            <option value="diesel">Diésel</option>
                            <option value="electrico">Eléctrico</option>
                            <option value="hibrido">Híbrido</option>
                        </select>
                    </div>
                </div>
            </section>

            <!-- Datos del Propietario -->
            <section class="form-section">
                <h2><i class="fas fa-user"></i> Datos del Propietario</h2>
                <div class="form-grid">
                    <div class="input-group">
                        <label for="tipo_propietario">Tipo de Propietario</label>
                        <select id="tipo_propietario" name="tipo_propietario" required>
                            <option value="">Seleccione tipo</option>
                            <option value="natural">Persona Natural</option>
                            <option value="juridica">Persona Jurídica</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label for="nombre_propietario">Nombre Completo</label>
                        <input type="text" id="nombre_propietario" name="nombre_propietario" required>
                    </div>
                    <div class="input-group">
                        <label for="numero_identificacion">Número de Identificación</label>
                        <input type="text" id="numero_identificacion" name="numero_identificacion" required>
                    </div>
                    <div class="input-group">
                        <label for="telefono">Teléfono</label>
                        <input type="text" id="telefono" name="telefono" required>
                    </div>
                    <div class="input-group wide">
                        <label for="domicilio">Domicilio</label>
                        <input type="text" id="domicilio" name="domicilio" required>
                    </div>
                </div>
            </section>

            <!-- Datos del Seguro -->
            <section class="form-section">
                <h2><i class="fas fa-shield-alt"></i> Datos del Seguro</h2>
                <div class="form-grid">
                    <div class="input-group">
                        <label for="aseguradora">Aseguradora</label>
                        <input type="text" id="aseguradora" name="aseguradora" required>
                    </div>
                    <div class="input-group">
                        <label for="numero_poliza">Número de Póliza</label>
                        <input type="text" id="numero_poliza" name="numero_poliza" required>
                    </div>
                    <div class="input-group">
                        <label for="fecha_inicio">Fecha de Inicio</label>
                        <input type="date" id="fecha_inicio" name="fecha_inicio" required>
                    </div>
                    <div class="input-group">
                        <label for="fecha_vencimiento">Fecha de Vencimiento</label>
                        <input type="date" id="fecha_vencimiento" name="fecha_vencimiento" required>
                    </div>
                </div>
            </section>

            <div class="actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Registrar Vehículo
                </button>
                <a href="../index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
            </div>
        </form>
    </div>
</body>
</html>